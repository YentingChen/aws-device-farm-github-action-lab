package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Pages.AbstractBasePages.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;

public class AlertPage extends BasePage {
    private static final String ALERT_ID = "Alert";

    private static final String MODAL_ID = "Modal";

    private static final String ALERT_MESSAGE_ID = "This is an alert";

    private static final String OK_ID = "OK";

    public AlertPage(AppiumDriver driver) {
        super(driver);
    }

    public void clickAlertButton() {
        WebElement alertButton = this.driver.findElement(AppiumBy.accessibilityId(ALERT_ID));
        alertButton.click();
    }

    public void clickModalButton() {
        WebElement modalButton = this.driver.findElement(AppiumBy.accessibilityId(MODAL_ID));
        modalButton.click();
    }

    public String getAlertText() {
        WebElement alertText = this.driver.findElement(AppiumBy.accessibilityId(ALERT_MESSAGE_ID));
        return alertText.getText();
    }

    public String getModalText() {
        WebElement modalText = this.driver.findElement(By.className(STATIC_TEXT_CLASS));
        return modalText.getText();
    }

    public void acceptMessage() {
        WebElement okButton = this.driver.findElement(AppiumBy.accessibilityId(OK_ID));
        okButton.click();
    }
}