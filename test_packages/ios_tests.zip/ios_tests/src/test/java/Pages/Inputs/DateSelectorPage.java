package Pages.Inputs;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;

public class DateSelectorPage extends InputPage {
    private static final int MONTH_INDEX = 0;

    private static final int DAY_INDEX = 1;

    private static final int YEAR_INDEX = 2;

    private static final int INPUT_INDEX = 2;
    WebDriverWait wait = new WebDriverWait(this.driver, Duration.ofSeconds(30));

    public DateSelectorPage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    public void setDateValues(String month, String day, String year) {
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(PICKER_WHEEL_CLASS)));
        List<WebElement> wheels = this.driver.findElements(By.className(PICKER_WHEEL_CLASS));
        WebElement monthWheel = wheels.get(MONTH_INDEX);
        WebElement dayWheel = wheels.get(DAY_INDEX);
        WebElement yearWheel = wheels.get(YEAR_INDEX);
        monthWheel.sendKeys(new CharSequence[] { month });
        dayWheel.sendKeys(new CharSequence[] { day });
        yearWheel.sendKeys(new CharSequence[] { year });
    }

    public String getSelectedDate() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className(STATIC_TEXT_CLASS)));
        WebElement selectedDate = this.driver.findElement(By.className(STATIC_TEXT_CLASS));
        return selectedDate.getText();
    }
}