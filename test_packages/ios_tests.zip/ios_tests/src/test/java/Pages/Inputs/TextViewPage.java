package Pages.Inputs;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TextViewPage extends InputPage {
    private static final int INPUT_INDEX = 0;

    public TextViewPage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    public String getTextViewContent() {
        WebElement textView = this.driver.findElement(By.className(TEXT_VIEW_CLASS));
        return textView.getText();
    }
}