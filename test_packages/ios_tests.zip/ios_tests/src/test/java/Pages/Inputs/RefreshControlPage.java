package Pages.Inputs;

import java.time.Duration;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;

public class RefreshControlPage extends InputPage {
    private static final int INPUT_INDEX = 4;

    private static final String REFRESH_TEXT_ID = "refreshText";

    WebDriverWait wait = new WebDriverWait(this.driver, Duration.ofSeconds(30));
    public RefreshControlPage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    private RemoteWebElement getRefreshElement(){
        return (RemoteWebElement) getElementById(REFRESH_TEXT_ID);
    }

    public String getText() {
        return getRefreshElement().getText();
    }

    public void refresh() {
        Dimension windowSize = driver.manage().window().getSize();
        int endY = (int) (windowSize.getHeight() * 3);
        drag(Duration.ofSeconds(1), getRefreshElement(), new Point(windowSize.getWidth(), endY));
    }
}
