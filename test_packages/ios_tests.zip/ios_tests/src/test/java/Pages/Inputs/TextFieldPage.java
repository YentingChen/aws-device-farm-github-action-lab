package Pages.Inputs;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;

public class TextFieldPage extends InputPage {
    private static final int INPUT_INDEX = 6;

    private WebElement getTextField(){
        return getElementByClassName(TEXT_FIELD_CLASS);
    }

    public TextFieldPage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    public String getTextFieldValue() {
        return getTextField().getAttribute("value");
    }

    public void inputText(String input) {
        getTextField().sendKeys(new CharSequence[] { input });
    }
}
