package Pages.Inputs;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;

public class SliderPage extends InputPage {
    private static final String VALUE_ATTRIBUTE = "value";

    private static final int INPUT_INDEX = 5;

    public SliderPage(AppiumDriver driver) {
        super(driver);
    }

    public WebElement getSlider(){
        return getElementByClassName(SLIDER_CLASS);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    public int getSliderValue() {
        return Integer.valueOf(getSlider().getAttribute(VALUE_ATTRIBUTE)).intValue();
    }

    public void tapSlider() {
        getSlider().click();
    }
}
