package Pages.Inputs;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;

public class TogglePage extends InputPage {

    private static final String PLUS_BUTTON_ID = "addButton";

    private static final String INFO_BUTTON_ID = "infoButton";

    private static final int INPUT_INDEX = 1;

    public TogglePage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }


    public void pressPlusButton() {
        WebElement plusButton = driver.findElement(AppiumBy.accessibilityId(PLUS_BUTTON_ID));
        plusButton.click();
    }

    public void pressInfoButton() {
        WebElement infoButton = driver.findElement(AppiumBy.accessibilityId(INFO_BUTTON_ID));
        infoButton.click();
    }
}