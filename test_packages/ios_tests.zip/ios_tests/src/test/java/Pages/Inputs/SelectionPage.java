package Pages.Inputs;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class SelectionPage extends InputPage {
    private static final int INPUT_INDEX = 8;

    public SelectionPage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    public void selectOnWheel(String selection) {
        WebElement selectionWheel = this.driver.findElement(By.className(PICKER_WHEEL_CLASS));
        selectionWheel.sendKeys(new CharSequence[] { selection });
    }

    public String getHeaderText() {
        WebElement selection = this.driver.findElement(By.className(STATIC_TEXT_CLASS));
        return selection.getText();
    }
}