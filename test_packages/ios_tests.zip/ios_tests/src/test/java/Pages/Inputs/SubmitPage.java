package Pages.Inputs;

import java.time.Duration;

import org.openqa.selenium.remote.RemoteWebElement;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;

public class SubmitPage extends InputPage {
    private static final int LONG_PRESS_DURATION = 6000;

    private static final String SUBMIT_ID = "Submit";

    private static final int INPUT_INDEX = 7;

    private RemoteWebElement getSubmitButton(){
        return (RemoteWebElement) getElementById(SUBMIT_ID);
    }

    public SubmitPage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    public void longPressSubmit() {
        longPress(getSubmitButton(), Duration.ofSeconds(1));
    }

    public boolean isSubmitButtonDisplayed() {
        return getSubmitButton().isDisplayed();
    }
}
