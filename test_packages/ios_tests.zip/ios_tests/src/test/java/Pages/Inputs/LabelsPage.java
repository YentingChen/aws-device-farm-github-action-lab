package Pages.Inputs;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LabelsPage extends InputPage {
    private static final String LABEL_1_ID = "I am label 1";

    private static final String LABEL_2_ID = "I am label 2";

    private static final int INPUT_INDEX = 3;

    public LabelsPage(AppiumDriver driver) {
        super(driver);
    }

    WebDriverWait wait = new WebDriverWait(this.driver, Duration.ofSeconds(30));
    public int getInputIndex() {
        return INPUT_INDEX;
    }

    public boolean isLabel1Displayed() {
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id(LABEL_1_ID)));
        WebElement label1 = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(LABEL_1_ID));
        return label1.isDisplayed();
    }

    public boolean isLabel2Displayed() {
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id(LABEL_2_ID)));
        WebElement label2 = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(LABEL_2_ID));
        return label2.isDisplayed();
    }
}
