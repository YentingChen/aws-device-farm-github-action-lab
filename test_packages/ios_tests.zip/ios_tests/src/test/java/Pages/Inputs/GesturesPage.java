package Pages.Inputs;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.remote.RemoteWebElement;

import Pages.AbstractBasePages.InputPage;
import io.appium.java_client.AppiumDriver;

public class GesturesPage extends InputPage {
    private static final int INPUT_INDEX = 9;
    private static final String BOX_XPATH_EXPRESSION = "//XCUIElementTypeImage[contains(@name,'solid.png')]";
    public GesturesPage(AppiumDriver driver) {
        super(driver);
    }

    public int getInputIndex() {
        return INPUT_INDEX;
    }

    private RemoteWebElement getBox(){
        return (RemoteWebElement) getElementByXpath(BOX_XPATH_EXPRESSION);
    }

    public Dimension getBoxDimensions() {
        return getBox().getSize();
    }

    public Point getBoxLocation() {
        return getBox().getLocation();
    }

    public void moveBox(int x, int y) {
        drag(Duration.ofSeconds(1), getBox(), new Point(x, y));
    }

    public void pinchBox() {
        Map<String, Object> pinch = new HashMap<>();
        pinch.put("scale", 0.2);
        pinch.put("velocity", -1);
        pinch.put("element", getBox().getId());
        driver.executeScript("mobile: pinch", pinch);

    }

    public void stretchBox(){
        Map<String, Object> pinch = new HashMap<>();
        pinch.put("scale", 1.5);
        pinch.put("velocity", 1.1);
        pinch.put("element", getBox().getId());
        driver.executeScript("mobile: pinch", pinch);
    }
}
