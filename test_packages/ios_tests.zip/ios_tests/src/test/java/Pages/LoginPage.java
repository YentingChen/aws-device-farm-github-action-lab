package Pages;

import Pages.AbstractBasePages.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import java.util.List;

public class LoginPage extends BasePage {
    private static final String LOGIN_SUCCESS_MESSAGE = "Logged in as admin";

    private static final String LOGIN_FAIL_MESSAGE = "PERMISSION DENIED";

    private static final String LOGIN_ID = "Login";

    private static final String LOG_OUT_ID = "log out";

    private static final String TRY_AGAIN_ID = "try again";

    public LoginPage(AppiumDriver driver) {
        super(driver);
    }

    public void login(String username, String password) {
        WebElement usernameField = this.driver.findElement(By.className(TEXT_FIELD_CLASS));
        WebElement passwordField = this.driver.findElement(By.className(SECURE_TEXT_FIELD_CLASS));
        usernameField.sendKeys(new CharSequence[] { username });
        passwordField.sendKeys(new CharSequence[] { password });
        String pageSource = this.driver.getPageSource();
        // The sample app built with Xcode 16+ on iPads made some changes to how our nav bar is
        // displayed so now we have 2 login buttons
        // The "Login" button on the nav bar and the "Login" button we actually want here
        List<WebElement> loginButtons = this.driver.findElements(AppiumBy.accessibilityId(LOGIN_ID));
        if (loginButtons.size() > 1) {
            loginButtons.get(1).click();
        } else{
            loginButtons.get(0).click();
        }
    }

    public boolean isValidLoginMessageDisplayed() {
        WebElement loggedInMessage = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(LOGIN_SUCCESS_MESSAGE));
        return loggedInMessage.isDisplayed();
    }

    public boolean isInvalidLoginMessageDisplayed() {
        WebElement permissionDeniedMessage = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(LOGIN_FAIL_MESSAGE));
        return permissionDeniedMessage.isDisplayed();
    }

    public boolean isBackAtLogin() {
        WebElement usernameField = this.driver.findElement(By.className(TEXT_FIELD_CLASS));
        WebElement passwordField = this.driver.findElement(By.className(SECURE_TEXT_FIELD_CLASS));
        WebElement loginButton = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(LOGIN_ID));
        return (loginButton.isDisplayed() && usernameField.isDisplayed() && passwordField.isDisplayed());
    }

    public void pressLogOutButton() {
        WebElement logOutButton = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(LOG_OUT_ID));
        logOutButton.click();
    }

    public void pressTryAgainButton() {
        WebElement tryAgainButton = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(TRY_AGAIN_ID));
        tryAgainButton.click();
    }
}
