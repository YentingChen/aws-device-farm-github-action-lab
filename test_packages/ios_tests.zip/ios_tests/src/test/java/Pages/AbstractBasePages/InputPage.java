package Pages.AbstractBasePages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumDriver;

public abstract class InputPage extends BasePage {

    private static final Duration DEFAULT_WAIT_TIMEOUT = Duration.ofSeconds(30);

    private static final double START_OFFSET = 0.95;
    private static final double END_OFFSET = 0.05;
    private static final double HEIGHT_OFFSET = 0.75;
    private static final int SWIPE_DURATION = 1000;
    public InputPage(AppiumDriver driver) {
        super(driver);
    }

    public void goToNextPage() {
        Dimension size = driver.manage().window().getSize();
        int startX = (int) (size.width * START_OFFSET);
        int endX = (int) (size.width * END_OFFSET);
        int startY = (int) (size.height * HEIGHT_OFFSET);
        drag(Duration.ofMillis(250), 
            new Point(startX, startY),
            new Point(endX, startY));
    }

    public WebElement getElementByClassName(final String className){
        WebDriverWait wait = new WebDriverWait(this.driver, DEFAULT_WAIT_TIMEOUT);
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(className)));
        return this.driver.findElement(By.className(className));
    }

    public WebElement getElementByXpath(final String xpath){
        WebDriverWait wait = new WebDriverWait(this.driver, DEFAULT_WAIT_TIMEOUT);
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath(xpath)));
        return driver.findElement(By.xpath(xpath));
    }

    public WebElement getElementById(final String id){
        WebDriverWait wait = new WebDriverWait(this.driver, DEFAULT_WAIT_TIMEOUT);
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id(id)));
        return this.driver.findElement(By.id(id));
    }

    public abstract int getInputIndex();
}
