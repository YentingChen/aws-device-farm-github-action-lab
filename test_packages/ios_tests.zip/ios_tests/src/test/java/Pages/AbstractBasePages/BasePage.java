package Pages.AbstractBasePages;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;

public abstract class BasePage {
    protected final AppiumDriver driver;

    protected static final String PICKER_WHEEL_CLASS = "UIAPickerWheel";

    protected static final String STATIC_TEXT_CLASS = "UIAStaticText";

    protected static final String IMAGE_CLASS = "UIAImage";

    protected static final String SLIDER_CLASS = "UIASwitch";

    protected static final String TEXT_FIELD_CLASS = "UIATextField";

    protected static final String TEXT_VIEW_CLASS = "UIATextView";

    protected static final String BUTTON_CLASS = "UIAButton";

    protected static final String COLLECTION_VIEW_CLASS = "UIACollectionView";

    protected static final String SCROLL_VIEW_CLASS = "UIAScrollView";

    protected static final String TABLE_VIEW_CLASS = "UIATableView";

    protected static final String WEB_VIEW_CLASS = "UIAWebView";

    protected static final String SECURE_TEXT_FIELD_CLASS = "UIASecureTextField";

    protected static final String ELEMENT_TYPE_IMAGE_CLASS = "XCUIElementTypeImage";

    protected static final String TAB_BAR_CLASS = "UIATabBar";

    protected static final String NAVIGATION_BAR_CLASS = "UIANavigationBar";

    protected static final String PAGE_INDICATOR_CLASS = "UIAPageIndicator";

    private static final int IMPLICIT_TIMEOUT_DURATION = 5;

    protected BasePage(AppiumDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void press(WebElement element) {
        element.click();
    }

    public void longPress(RemoteWebElement element, Duration duration) {
        Map<String, Object> args = new HashMap<>();
        args.put("elementId", element.getId());
        args.put("duration", asActionSeconds(duration));
        this.driver.executeScript("mobile: touchAndHold", args);
    }

    public void drag(Duration duration, Point start, Point end) {
        Map<String, Object> args = new HashMap<>();
        args.put("duration", asActionSeconds(duration));
        args.put("fromX", start.getX());
        args.put("fromY", start.getY());
        args.put("toX", end.getX());
        args.put("toY", end.getY());
        this.driver.executeScript("mobile: dragFromToForDuration", args);
    }

    public void drag(Duration duration, RemoteWebElement element, Point end) {
        Point topLeftPoint = element.getLocation();
        int leftX = topLeftPoint.getX();
        int width = element.getSize().getWidth();
        int centerX = width + (leftX / 2);

        int topY = topLeftPoint.getY();
        int height = element.getSize().getHeight();
        int centerY = topY + (height / 2);

        int startX = centerX;
        int startY = centerY;

        // Finish this motion in the duration specified
        int pixelsToCover = (int) Math.hypot(Math.abs(startX - end.getX()), Math.abs(startY - end.getY()));
        double pixelsPerSecond = pixelsToCover / ((double) duration.toMillis() / 1000);

        Map<String, Object> args = new HashMap<>();
        args.put("pressDuration", 0.25);
        args.put("holdDuration", 0.25);
        args.put("velocity", pixelsPerSecond);
        args.put("fromX", startX);
        args.put("fromY", startY);
        args.put("toX", end.getX());
        args.put("toY", end.getY());
        this.driver.executeScript("mobile: dragFromToWithVelocity", args);
    }

    // Convert duration to millisecond-precision seconds
    private static double asActionSeconds(Duration duration) {
        return (double) duration.toMillis() / 1000;
    }

}
