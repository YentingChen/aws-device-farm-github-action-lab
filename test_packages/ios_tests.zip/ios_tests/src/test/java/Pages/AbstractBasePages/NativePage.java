package Pages.AbstractBasePages;

import io.appium.java_client.AppiumDriver;

import java.util.HashMap;
import java.util.Map;

public abstract class NativePage extends BasePage {
    public NativePage(AppiumDriver driver) {
        super(driver);
    }

    public void scrollDown() {
        Map<String, Object> args = new HashMap();
        args.put("direction", "down");
        driver.executeScript("mobile: scroll", args);
    }
}