package Pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Function;

import Pages.AbstractBasePages.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.remote.SupportsContextSwitching;

public class HybridPage extends BasePage {
    private static final long LOAD_TIME = 15L;

    private static final String WEB_CONTAINER_CLASSNAME = "awsdocs-container";

    private static final String NATIVE_APP = "NATIVE_APP";

    private static final String NAVIGATION_BAR_ID = "navigation bar";


    public HybridPage(AppiumDriver driver) {
        super(driver);
    }

    public void goToUrl(String url) throws InterruptedException {
        ((SupportsContextSwitching) this.driver).context(NATIVE_APP);
        WebElement navigationBar = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(NAVIGATION_BAR_ID));
        navigationBar.sendKeys(new CharSequence[] { url + "\n" });
        WebDriverWait wait = new WebDriverWait((WebDriver)this.driver, Duration.ofSeconds(15));
        wait.until((Function)ExpectedConditions.presenceOfElementLocated(By.className(WEB_VIEW_CLASS)));
    }

    public WebElement getWebHeader() throws InterruptedException {
        Object[] contextHandles = ((SupportsContextSwitching) this.driver).getContextHandles().toArray();
        String webViewContent = (String)contextHandles[contextHandles.length - 1];
        WebDriver webDriver = ((SupportsContextSwitching) this.driver).context(webViewContent);
        WebDriverWait wait = new WebDriverWait(webDriver, Duration.ofSeconds(15));
        wait.until((Function)ExpectedConditions.presenceOfElementLocated(By.className(WEB_CONTAINER_CLASSNAME)));
        wait.until((Function)ExpectedConditions.visibilityOfElementLocated(By.className(WEB_CONTAINER_CLASSNAME)));
        WebElement webHeader = webDriver.findElement(By.className(WEB_CONTAINER_CLASSNAME));
        return webHeader;
    }
}
