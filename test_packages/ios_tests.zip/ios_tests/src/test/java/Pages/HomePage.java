package Pages;

import Pages.AbstractBasePages.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;

public class HomePage extends BasePage {
    private static final String HEADLINE_ID = "AWS Device Farm Sample app";

    private static final String SUBHEADER_ID = "Version 1";

    public HomePage(AppiumDriver driver) {
        super(driver);
    }

    public String getHeadlineValue() {
        WebElement headline = this.driver.findElement(AppiumBy.accessibilityId(HEADLINE_ID));
        return headline.getText();
    }

    public String getSubheaderValue() {
        WebElement subheader = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(SUBHEADER_ID));
        return subheader.getText();
    }
}