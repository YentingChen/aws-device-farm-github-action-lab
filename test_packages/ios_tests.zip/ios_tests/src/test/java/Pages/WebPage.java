package Pages;

import Pages.AbstractBasePages.BasePage;

import java.time.Duration;
import java.util.Set;

import com.google.common.base.Function;
import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.SupportsContextSwitching;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebPage extends BasePage {

    private static final String NAVIGATION_BAR_ID = "navigation bar";
    private static final String NATIVE_APP = "NATIVE_APP";
    private static final String BACK_ID = "Input a website";
    private static final int WEBDRIVER_WAIT_TIME = 10;
    private static final int WEBSITE_LOAD_DELAY = 5000;
    private static final int SLEEP_DELAY = 2000;
    private static final int WEB_CONTEXT_RETRIES = 20;

    public WebPage(IOSDriver driver) {
        super(driver);
    }

    public String getLabelText(String url, String id) throws InterruptedException {
        WebElement webElement = goToUrlAndReturnWebElementById(url, id);
        assert webElement != null;
        return webElement.getText();
    }

    public void goBackToNavigationBar() {
        ((SupportsContextSwitching) driver).context(NATIVE_APP);
        WebDriverWait wait = new WebDriverWait((WebDriver)driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(BACK_ID)));
        this.driver.findElement(AppiumBy.accessibilityId(BACK_ID)).click();
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(NAVIGATION_BAR_ID)));
    }

    public boolean validateCheckboxSelected(String url, String id) throws InterruptedException {
        WebElement webElement = goToUrlAndReturnWebElementById(url, id);
        assert webElement != null;
        webElement.click();
        return webElement.isSelected();
    }

    public boolean validatePasswordInputText(String url, String id) throws InterruptedException {
        WebElement webElement = goToUrlAndReturnWebElementById(url, id);
        String passwordText = "vpcenipassword";
        assert webElement != null;
        webElement.sendKeys(passwordText);
        Thread.sleep(SLEEP_DELAY);
        return webElement.getAttribute("value").equals(passwordText);
    }

    public void deleteAllCookies(String url) throws InterruptedException{
        goToUrlAndReturnWebElementById(url , "tg-ele-emailid");
        driver.manage().deleteAllCookies();
    }

    public boolean isWebViewDisplayed() {
        WebDriverWait wait = new WebDriverWait((WebDriver)this.driver, Duration.ofSeconds(10));
        WebElement webView = (WebElement)wait.until((Function)ExpectedConditions.visibilityOfElementLocated(By.className(WEB_VIEW_CLASS)));
        return webView.isDisplayed();
    }

    private void goToUrl(String url) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait((WebDriver)driver, Duration.ofSeconds(15));
        wait.until((Function)ExpectedConditions.presenceOfElementLocated(By.id(NAVIGATION_BAR_ID)));
        WebElement navigationBar = driver.findElement(AppiumBy.accessibilityId(NAVIGATION_BAR_ID));
        navigationBar.sendKeys(new CharSequence[] { url + "\n" });
        wait.until((Function)ExpectedConditions.presenceOfElementLocated(By.className(WEB_VIEW_CLASS)));
        Thread.sleep(WEBSITE_LOAD_DELAY);
    }

    private WebElement goToUrlAndReturnWebElementById(String url, String id) throws InterruptedException {
        SupportsContextSwitching contextDriver = (SupportsContextSwitching) driver;
        contextDriver.context(NATIVE_APP);
        goToUrl(url);
        WebDriverWait wait = new WebDriverWait(contextDriver, Duration.ofSeconds(WEBDRIVER_WAIT_TIME));
        String cssId = "#" + id;
        Set<String> contexts = null;
        for(int i = 0; i <= WEB_CONTEXT_RETRIES; i++) {
            contexts = contextDriver.getContextHandles();
            if (contexts.size() > 1) {
                break;
            }
            Thread.sleep(SLEEP_DELAY);
        }
        for (String context : contexts) {
            System.out.println(context);
            if (context.contains("WEB")) {
                WebDriver webDriver = contextDriver.context(context);
                webDriver.get(url);
                wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(cssId)));
                return webDriver.findElement(By.cssSelector(cssId));
            }
        }
        return null;
    }
}
