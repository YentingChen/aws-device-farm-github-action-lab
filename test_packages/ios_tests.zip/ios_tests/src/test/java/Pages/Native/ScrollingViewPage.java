package Pages.Native;

import Pages.AbstractBasePages.NativePage;
import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ScrollingViewPage extends NativePage {
    public ScrollingViewPage(AppiumDriver driver) {
        super(driver);
    }

    public boolean isScrollViewDisplayed() {
        WebElement scrollView = this.driver.findElement(By.className(SCROLL_VIEW_CLASS));
        return scrollView.isDisplayed();
    }
}