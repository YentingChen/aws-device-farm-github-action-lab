package Pages.Native;

import Pages.AbstractBasePages.NativePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;

public class OutOfViewComponentPage extends NativePage {
    private static final String HIDDEN_TEXT_ID = "This is hidden text";

    public OutOfViewComponentPage(AppiumDriver driver) {
        super(driver);
    }

    public boolean isHiddenTextDisplayed() {
        WebElement hiddenText = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(HIDDEN_TEXT_ID));
        return hiddenText.isDisplayed();
    }
}