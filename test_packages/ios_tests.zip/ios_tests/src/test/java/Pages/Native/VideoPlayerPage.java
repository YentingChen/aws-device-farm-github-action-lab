package Pages.Native;

import Pages.AbstractBasePages.NativePage;
import com.google.common.base.Function;
import io.appium.java_client.AppiumDriver;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class VideoPlayerPage extends NativePage {
    private static final String MEDIA_PLAYER_ID = "MediaPlayerView";

    private static final int LOAD_TIME = 10;

    public VideoPlayerPage(AppiumDriver driver) {
        super(driver);
    }

    public boolean isVideoDisplayed() {
        WebDriverWait wait = new WebDriverWait((WebDriver)this.driver, Duration.ofSeconds(10));
        WebElement videoPlayer = (WebElement)wait.until((Function)ExpectedConditions.visibilityOfElementLocated(By.id(MEDIA_PLAYER_ID)));
        return videoPlayer.isDisplayed();
    }
}