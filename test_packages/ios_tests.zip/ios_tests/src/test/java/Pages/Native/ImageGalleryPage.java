package Pages.Native;

import Pages.AbstractBasePages.NativePage;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ImageGalleryPage extends NativePage {

    WebDriverWait wait = new WebDriverWait(this.driver, Duration.ofSeconds(20));
    public ImageGalleryPage(AppiumDriver driver) {
        super(driver);
    }

    public boolean imageGalleryIsDisplayed() throws InterruptedException {
        Thread.sleep(2000);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className(COLLECTION_VIEW_CLASS)));
        WebElement imageGallery = this.driver.findElement(By.className(COLLECTION_VIEW_CLASS));
        return imageGallery.isDisplayed();
    }
}