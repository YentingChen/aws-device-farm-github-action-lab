package Pages.Native;

import Pages.AbstractBasePages.NativePage;
import io.appium.java_client.AppiumDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class TableOfElementsPage extends NativePage {
    public TableOfElementsPage(AppiumDriver driver) {
        super(driver);
    }

    public boolean isTableViewDisplayed() {
        WebElement tableView = this.driver.findElement(By.className(TABLE_VIEW_CLASS));
        return tableView.isDisplayed();
    }
}