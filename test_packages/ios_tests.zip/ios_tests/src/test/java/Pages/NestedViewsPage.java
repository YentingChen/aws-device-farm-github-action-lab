package Pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Pages.AbstractBasePages.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;

public class NestedViewsPage extends BasePage {
    private static final String NEXT_ID = "Next";
    private static final String BACK_ID = "Back";

    WebDriverWait wait = new WebDriverWait(this.driver, Duration.ofSeconds(30));
    public NestedViewsPage(AppiumDriver driver) {
        super(driver);
    }

    public void pressNextButton() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(NEXT_ID)));
        this.driver.findElement(AppiumBy.accessibilityId(NEXT_ID)).click();
    }

    public void pressBackButton() {
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id(BACK_ID)));
        this.driver.findElement(AppiumBy.accessibilityId(BACK_ID)).click();
    }

    public String getStaticText() throws InterruptedException {
        Thread.sleep(2000);
        List<WebElement> staticTexts= wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.className(STATIC_TEXT_CLASS)));
        WebElement nestedText = (WebElement) staticTexts.get(staticTexts.size() - 1);
        return nestedText.getText();
    }
}