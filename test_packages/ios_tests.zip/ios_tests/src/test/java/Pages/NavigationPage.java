package Pages;

import Pages.AbstractBasePages.BasePage;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class NavigationPage extends BasePage {
    private static final String INPUT_ID = "Inputs";

    private static final String MORE_ID = "More";

    private static final String NEXT_PAGE_ID = "Next Page";

    private static final String NATIVE_ID = "Native";

    private static final String MORE_CATEGORIES = "Nested|Crash|Alerts|Web|Login";

    private static final String NATIVE_CATEGORIES = "Image Gallery|Scrolling View|Table of elements|Video Player|Camera|Out of View Component";

    private static final String INPUT_CATEGORIES = "Date Selector|Gestures|Labels|Refresh Control|Selection|Slider|Submit|Text Field|Text View|Toggle";

    public NavigationPage(AppiumDriver driver) {
        super(driver);
    }

    public void goToCategory(String categoryName) {
        if (categoryName.matches(INPUT_CATEGORIES)) {
            WebElement inputButton = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(INPUT_ID));
            inputButton.click();
            return;
        }
        if (categoryName.matches(MORE_CATEGORIES)) {
            List<WebElement> buttons = this.driver.findElements(AppiumBy.accessibilityId(MORE_ID));
            if (buttons.isEmpty()) {
                WebElement nextPageButton = (WebElement) this.driver.findElement(AppiumBy.accessibilityId(NEXT_PAGE_ID));
                nextPageButton.click();
            } else {
                buttons.get(0).click();
            }
        } else if (categoryName.matches(NATIVE_CATEGORIES)) {
            WebElement nativeButton = (WebElement)this.driver.findElement(AppiumBy.accessibilityId(NATIVE_ID));
            nativeButton.click();
        }
        WebElement categoryButton = (WebElement) this.driver.findElement(AppiumBy.accessibilityId(categoryName));
        categoryButton.click();
    }
}
