package Tests;

import Pages.HomePage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class HomeTest extends BaseTest {
    private static final String HOMEPAGE_HEADLINE = "AWS Device Farm Sample app";

    private static final String HOMEPAGE_SUBHEADER = "Version 1";

    private static final String PAGE_NAME = "Home";

    private HomePage homePageTest;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.homePageTest = new HomePage((AppiumDriver)driver);
    }

    @Test
    public void testHomePageHeadline() {
        Assert.assertEquals(this.homePageTest.getHeadlineValue(), HOMEPAGE_HEADLINE);
    }

    @Test
    public void testHomePageSubheader() {
        Assert.assertEquals(this.homePageTest.getSubheaderValue(), HOMEPAGE_SUBHEADER);
    }
}