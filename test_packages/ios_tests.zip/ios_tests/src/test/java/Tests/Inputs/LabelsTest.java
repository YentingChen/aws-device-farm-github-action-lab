package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.LabelsPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LabelsTest extends InputTest {
    private static final String PAGE_NAME = "Labels";

    private LabelsPage labelsPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new LabelsPage((AppiumDriver)driver);
        this.labelsPage = (LabelsPage)this.page;
    }

    @Test
    public void testLabels() {
        Assert.assertTrue(this.labelsPage.isLabel1Displayed());
        Assert.assertTrue(this.labelsPage.isLabel2Displayed());
    }
}
