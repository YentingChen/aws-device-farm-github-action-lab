package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.DateSelectorPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DateSelectorTest extends InputTest {
    private static final String EXPECTED_DATE = "Jul 5, 1994";

    private static final String MONTH = "July";

    private static final String DAY = "5";

    private static final String YEAR = "1994";

    private static final String PAGE_NAME = "Date Selector";

    private DateSelectorPage dateSelectorPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new DateSelectorPage((AppiumDriver)driver);
        this.dateSelectorPage = (DateSelectorPage)this.page;
    }

    @Test
    public void testSelectDate() {
        this.dateSelectorPage.setDateValues(MONTH, DAY, YEAR);
        Assert.assertEquals(this.dateSelectorPage.getSelectedDate(), EXPECTED_DATE);
    }
}