package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.GesturesPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;

import java.time.Duration;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class GesturesTest extends InputTest {
    private static final String PAGE_NAME = "Gestures";

    private GesturesPage gesturesPage;

    public String getName() {
        return PAGE_NAME;
    }

    private void assertDimensionsGreaterThan(Dimension dim1, Dimension dim2) {
        Assert.assertTrue((dim1.getHeight() > dim2.getHeight()));
        Assert.assertTrue((dim1.getWidth() > dim2.getWidth()));
    }

    private void assertDimensionsLessThan(Dimension dim1, Dimension dim2) {
        assertDimensionsGreaterThan(dim2, dim1);
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new GesturesPage((AppiumDriver)driver);
        this.gesturesPage = (GesturesPage)this.page;
    }

    @Test
    public void testMove() {
        int MOVE_OFFSET = 30;
        Point originalLocation = this.gesturesPage.getBoxLocation();
        int halfWidth = originalLocation.getX();
        int halfHeight = originalLocation.getY();
        this.gesturesPage.moveBox(halfWidth+MOVE_OFFSET, halfHeight-MOVE_OFFSET);
        Assert.assertNotEquals(originalLocation.toString(), this.gesturesPage.getBoxLocation().toString());
    }

    @Test
    public void testResize() {
        Dimension originalDimensions = this.gesturesPage.getBoxDimensions();
        this.gesturesPage.stretchBox();
        Dimension stretchedDimensions = this.gesturesPage.getBoxDimensions();
        assertDimensionsGreaterThan(stretchedDimensions, originalDimensions);
        this.gesturesPage.pinchBox();
        Dimension pinchedDimensions = this.gesturesPage.getBoxDimensions();
        assertDimensionsLessThan(pinchedDimensions, stretchedDimensions);
    }
}
