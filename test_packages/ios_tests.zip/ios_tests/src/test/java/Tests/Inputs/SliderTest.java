package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.SliderPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SliderTest extends InputTest {
    private static final String PAGE_NAME = "Slider";

    private SliderPage sliderPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new SliderPage((AppiumDriver)driver);
        this.sliderPage = (SliderPage)this.page;
    }

    @Test
    public void testSlider() {
        Assert.assertEquals(this.sliderPage.getSliderValue(), 0);
        this.sliderPage.tapSlider();
        Assert.assertEquals(this.sliderPage.getSliderValue(), 1);
        this.sliderPage.tapSlider();
        Assert.assertEquals(this.sliderPage.getSliderValue(), 0);
    }
}
