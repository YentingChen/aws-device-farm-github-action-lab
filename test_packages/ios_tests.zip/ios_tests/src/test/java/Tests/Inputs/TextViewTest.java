package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.TextViewPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TextViewTest extends InputTest {
    private static final String EXPECTED_TEXT = "I am a textview";

    private static final String PAGE_NAME = "Text View";

    private TextViewPage textViewPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new TextViewPage((AppiumDriver)driver);
        this.textViewPage = (TextViewPage)this.page;
    }

    @Test
    public void testTextView() {
        Assert.assertEquals(this.textViewPage.getTextViewContent(), EXPECTED_TEXT);
    }
}