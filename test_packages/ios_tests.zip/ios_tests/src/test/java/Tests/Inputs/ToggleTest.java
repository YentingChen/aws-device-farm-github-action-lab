package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.TogglePage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ToggleTest extends InputTest {

    private static final String PAGE_NAME = "Toggle";

    private TogglePage togglePage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new TogglePage((AppiumDriver)driver);
        this.togglePage = (TogglePage)this.page;
    }

    @Test
    public void testToggle() {
        this.togglePage.pressPlusButton();
        this.togglePage.pressInfoButton();
        this.togglePage.pressPlusButton();
    }
}