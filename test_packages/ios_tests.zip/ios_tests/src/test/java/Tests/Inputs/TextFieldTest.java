package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.TextFieldPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TextFieldTest extends InputTest {
    private static final String INPUT_STRING = "Amazon";

    private static final String PAGE_NAME = "Text Field";

    private TextFieldPage textFieldPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new TextFieldPage((AppiumDriver)driver);
        this.textFieldPage = (TextFieldPage)this.page;
    }

    @Test
    public void testTextField() {
        this.textFieldPage.inputText(INPUT_STRING);
        Assert.assertEquals(this.textFieldPage.getTextFieldValue(), INPUT_STRING);
    }
}
