package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.RefreshControlPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class RefreshControlTest extends InputTest {
    private static final String INITIAL_TEXT = "Refresh to get the time";

    private static final String PAGE_NAME = "Refresh Control";

    private RefreshControlPage refreshControlPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new RefreshControlPage((AppiumDriver)driver);
        this.refreshControlPage = (RefreshControlPage)this.page;
    }

    @Test
    public void testRefresh() {
        Assert.assertEquals(this.refreshControlPage.getText(), INITIAL_TEXT);
        this.refreshControlPage.refresh();
        Assert.assertNotEquals(this.refreshControlPage.getText(), INITIAL_TEXT);
    }
}
