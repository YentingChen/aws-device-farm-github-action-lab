package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.SubmitPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SubmitTest extends InputTest {
    private static final String PAGE_NAME = "Submit";

    private SubmitPage submitPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new SubmitPage((AppiumDriver)driver);
        this.submitPage = (SubmitPage)this.page;
    }

    @Test
    public void testSubmit() {
        Assert.assertTrue(this.submitPage.isSubmitButtonDisplayed());
        this.submitPage.longPressSubmit();
        Assert.assertTrue(this.submitPage.isSubmitButtonDisplayed());
    }
}
