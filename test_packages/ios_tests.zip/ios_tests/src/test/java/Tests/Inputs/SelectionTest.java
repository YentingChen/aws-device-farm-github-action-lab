package Tests.Inputs;

import Pages.AbstractBasePages.InputPage;
import Pages.Inputs.SelectionPage;
import Tests.AbstractBaseTests.InputTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SelectionTest extends InputTest {
    private static final String SUBMIT = "Submit";

    private static final String SELECTION = "Selection 3";

    private static final String PAGE_NAME = "Selection";

    private SelectionPage selectionPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.page = (InputPage)new SelectionPage((AppiumDriver)driver);
        this.selectionPage = (SelectionPage)this.page;
    }

    @Test
    public void testSelection() {
        Assert.assertEquals(this.selectionPage.getHeaderText(), SUBMIT);
        this.selectionPage.selectOnWheel(SELECTION);
        Assert.assertEquals(this.selectionPage.getHeaderText(), SELECTION);
    }
}