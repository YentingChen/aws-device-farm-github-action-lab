package Tests.AbstractBaseTests;

import Pages.NavigationPage;
import com.google.common.collect.ImmutableMap;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.WebElement;
import io.appium.java_client.appmanagement.ApplicationState;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public abstract class BaseTest {
    private static final long TIMEOUT = 35L;

    public static IOSDriver driver;

    protected NavigationPage navigationPage;

    public abstract String getName();

    @BeforeTest(alwaysRun = true)
    public abstract void setUpPage();

    WebDriverWait wait;
    @BeforeSuite(alwaysRun = true)
    public void setUpAppium() throws MalformedURLException {
        String URL_STRING = "http://127.0.0.1:4723/wd/hub";
        URL url = new URL(URL_STRING);
        XCUITestOptions options = new XCUITestOptions();
        System.out.println("Creating a new session at: " + URL_STRING + " with capabilities: " + options);
        driver = new IOSDriver(url, options);
        driver.manage().timeouts().implicitlyWait(TIMEOUT, TimeUnit.SECONDS);
    }

    @AfterSuite(alwaysRun = true)
    public void tearDownAppium() {
        driver.quit();
    }

    @BeforeClass(alwaysRun = true)
    public void navigateTo() {
        driver.executeScript("mobile: launchApp", ImmutableMap.of("bundleId", "Amazon.AWSDeviceFarmiOSReferenceApp"));
        ApplicationState state = driver.queryAppState("Amazon.AWSDeviceFarmiOSReferenceApp");
        wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.id("Home")));
        this.navigationPage = new NavigationPage((AppiumDriver)driver);
        this.navigationPage.goToCategory(getName());
    }

    @AfterClass(alwaysRun = true)
    public void restartApp() {
        driver.executeScript("mobile: terminateApp", ImmutableMap.of("bundleId", "Amazon.AWSDeviceFarmiOSReferenceApp"));
        driver.executeScript("mobile: launchApp", ImmutableMap.of("bundleId", "Amazon.AWSDeviceFarmiOSReferenceApp"));
    }
}
