package Tests.AbstractBaseTests;

import Pages.AbstractBasePages.InputPage;
import Pages.NavigationPage;
import io.appium.java_client.AppiumDriver;
import org.testng.annotations.BeforeClass;

public abstract class InputTest extends BaseTest {
    protected InputPage page;

    @BeforeClass
    public void navigateTo() {
        this.navigationPage = new NavigationPage((AppiumDriver)driver);
        this.navigationPage.goToCategory(getName());
        goToMyInputPage();
    }

    private void goToMyInputPage() {
        for (int i = 0; i < this.page.getInputIndex(); i++){
            this.page.goToNextPage();
        }
    }
}
