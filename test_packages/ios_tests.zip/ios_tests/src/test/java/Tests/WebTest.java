package Tests;

import Pages.WebPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class WebTest extends BaseTest {
    private static final String PAGE_NAME = "Web";

    private WebPage webPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.webPage = new WebPage((IOSDriver)driver);
    }

    @Test
    public void testWebView() {
        Assert.assertTrue(this.webPage.isWebViewDisplayed());
    }
}