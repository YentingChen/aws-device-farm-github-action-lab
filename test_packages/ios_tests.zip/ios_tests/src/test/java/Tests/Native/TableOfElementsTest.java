package Tests.Native;

import Pages.Native.TableOfElementsPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TableOfElementsTest extends BaseTest {
    private static final String PAGE_NAME = "Table of elements";

    private TableOfElementsPage tableOfElementsPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.tableOfElementsPage = new TableOfElementsPage((AppiumDriver)driver);
    }

    @Test
    public void testTableOfElements() {
        Assert.assertTrue(this.tableOfElementsPage.isTableViewDisplayed());
        this.tableOfElementsPage.scrollDown();
        Assert.assertTrue(this.tableOfElementsPage.isTableViewDisplayed());
    }
}
