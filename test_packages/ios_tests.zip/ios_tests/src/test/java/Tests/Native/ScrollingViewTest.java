package Tests.Native;

import Pages.Native.ScrollingViewPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ScrollingViewTest extends BaseTest {
    private static final String PAGE_NAME = "Scrolling View";

    private ScrollingViewPage scrollingViewPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.scrollingViewPage = new ScrollingViewPage((AppiumDriver)driver);
    }

    @Test
    public void testScroll() {
        this.scrollingViewPage.scrollDown();
        Assert.assertTrue(this.scrollingViewPage.isScrollViewDisplayed());
    }
}
