package Tests.Native;

import Pages.Native.CameraPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.NoAlertPresentException;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class CameraTest extends BaseTest {
    private static final String PAGE_NAME = "Camera";

    private CameraPage cameraPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.cameraPage = new CameraPage((AppiumDriver)driver);
    }

    @Test
    public void testCameraView() {
        try {
            driver.switchTo().alert().accept();
        } catch (NoAlertPresentException ignored) {

        }
        Assert.assertTrue(this.cameraPage.isCameraViewDisplayed());
    }
}