package Tests.Native;

import Pages.Native.VideoPlayerPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class VideoPlayerTest extends BaseTest {
    private static final String PAGE_NAME = "Video Player";

    private VideoPlayerPage videoPlayerPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.videoPlayerPage = new VideoPlayerPage((AppiumDriver)driver);
    }

    @Test
    public void testVideoPlayer() {
        Assert.assertTrue(this.videoPlayerPage.isVideoDisplayed());
    }
}