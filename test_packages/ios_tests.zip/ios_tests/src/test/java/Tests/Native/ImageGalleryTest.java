package Tests.Native;

import Pages.Native.ImageGalleryPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ImageGalleryTest extends BaseTest {
    private static final String PAGE_NAME = "Image Gallery";

    private ImageGalleryPage imageGalleryPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.imageGalleryPage = new ImageGalleryPage((AppiumDriver)driver);
    }

    @Test
    public void testImageGallery() throws InterruptedException {
        retryGetImageGallery(20);
        Assert.assertTrue(this.imageGalleryPage.imageGalleryIsDisplayed());
    }

    private void retryGetImageGallery(int retryAmount) throws InterruptedException {
        for(int i = 0; i < retryAmount; i++){
            if (this.imageGalleryPage.imageGalleryIsDisplayed()){
                break;
            }
        }
    }
}