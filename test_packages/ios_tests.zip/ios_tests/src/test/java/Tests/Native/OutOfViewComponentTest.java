package Tests.Native;

import Pages.Native.OutOfViewComponentPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class OutOfViewComponentTest extends BaseTest {
    private static final long TIMEOUT = 1000L;

    private static final String PAGE_NAME = "Out of View Component";

    private OutOfViewComponentPage outOfViewComponentPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.outOfViewComponentPage = new OutOfViewComponentPage((AppiumDriver)driver);
    }

    @Test
    public void testOutOfViewComponent() {
        this.outOfViewComponentPage.scrollDown();
        this.outOfViewComponentPage.scrollDown();
        this.outOfViewComponentPage.scrollDown();
        Assert.assertTrue(this.outOfViewComponentPage.isHiddenTextDisplayed());
    }
}
