package Tests;

import Pages.AlertPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AlertTest extends BaseTest {
    private static final String MODAL_MESSAGE = "This is a modal view";

    private static final String ALERT_MESSAGE = "This is an alert";

    private static final String PAGE_NAME = "Alerts";

    private AlertPage alertPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.alertPage = new AlertPage((AppiumDriver)driver);
    }

    @Test
    public void testAlertMessage() {
        this.alertPage.clickAlertButton();
        Assert.assertEquals(this.alertPage.getAlertText(), ALERT_MESSAGE);
        this.alertPage.acceptMessage();
    }

    @Test
    public void testModalMessage() {
        this.alertPage.clickModalButton();
        Assert.assertEquals(this.alertPage.getModalText(), MODAL_MESSAGE);
        this.alertPage.acceptMessage();
    }
}