package Tests;

import Pages.LoginPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class LoginTest extends BaseTest {
    private static final String VALID_USERNAME = "admin";

    private static final String VALID_PASSWORD = "password";

    private static final String INVALID_USERNAME = "Wrong User";

    private static final String INVALID_PASSWORD = "12345";

    private static final String PAGE_NAME = "Login";

    private LoginPage loginPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.loginPage = new LoginPage((AppiumDriver)driver);
    }

    @AfterMethod
    public void verifyBackAtLogin() {
        Assert.assertTrue(this.loginPage.isBackAtLogin());
    }

    @Test
    public void testValidLogin() {
        this.loginPage.login(VALID_USERNAME, VALID_PASSWORD);
        Assert.assertTrue(this.loginPage.isValidLoginMessageDisplayed());
        this.loginPage.pressLogOutButton();
    }

    @Test
    public void testInvalidLogin() {
        this.loginPage.login(INVALID_USERNAME, INVALID_PASSWORD);
        Assert.assertTrue(this.loginPage.isInvalidLoginMessageDisplayed());
        this.loginPage.pressTryAgainButton();
    }
}
