package Tests;

import Pages.HybridPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class HybridTest extends BaseTest {
    private static final String FULL_URL = "http://aws.amazon.com/documentation/devicefarm/";

    private static final String PAGE_NAME = "HTTP";

    private HybridPage hybridPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.hybridPage = new HybridPage((AppiumDriver)driver);
    }

    @Test
    public void testWebTitle() throws InterruptedException {
        this.hybridPage.goToUrl(FULL_URL);
        Assert.assertNotNull(this.hybridPage.getWebHeader());
    }
}
