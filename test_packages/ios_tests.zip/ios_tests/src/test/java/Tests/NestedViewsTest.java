package Tests;

import Pages.NestedViewsPage;
import Tests.AbstractBaseTests.BaseTest;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NestedViewsTest extends BaseTest {
    private static final String FIRST_VIEW = "This is the first view";

    private static final String SECOND_VIEW = "This is the second view";

    private static final String THIRD_VIEW = "This is the third view";

    private static final String FOURTH_VIEW = "This is the fourth view";

    private static final String PAGE_NAME = "Nested";

    private NestedViewsPage nestedViewsPage;

    public String getName() {
        return PAGE_NAME;
    }

    @BeforeTest
    public void setUpPage() {
        this.nestedViewsPage = new NestedViewsPage((AppiumDriver)driver);
    }

    @Test
    public void testNested() throws InterruptedException {
        Assert.assertEquals(this.nestedViewsPage.getStaticText(), FIRST_VIEW);
        this.nestedViewsPage.pressNextButton();
        Assert.assertEquals(this.nestedViewsPage.getStaticText(), SECOND_VIEW);
        this.nestedViewsPage.pressNextButton();
        Assert.assertEquals(this.nestedViewsPage.getStaticText(), THIRD_VIEW);
        this.nestedViewsPage.pressNextButton();
        Assert.assertEquals(this.nestedViewsPage.getStaticText(), FOURTH_VIEW);
        this.nestedViewsPage.pressBackButton();
        retryGetStaticText(30, THIRD_VIEW);
        Assert.assertEquals(this.nestedViewsPage.getStaticText(), THIRD_VIEW);
        this.nestedViewsPage.pressBackButton();
        retryGetStaticText(30, SECOND_VIEW);
        Assert.assertEquals(this.nestedViewsPage.getStaticText(), SECOND_VIEW);
        this.nestedViewsPage.pressBackButton();
        retryGetStaticText(30, FIRST_VIEW);
        Assert.assertEquals(this.nestedViewsPage.getStaticText(), FIRST_VIEW);
    }

    private void retryGetStaticText(int retryAmount, String expectedResult) throws InterruptedException {
        for(int i = 0; i < retryAmount; i++){
            if (expectedResult.equals(this.nestedViewsPage.getStaticText())){
                break;
            }
        }
    }
}
